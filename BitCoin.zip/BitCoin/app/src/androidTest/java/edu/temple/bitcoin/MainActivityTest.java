package edu.temple.bitcoin;


import android.support.test.espresso.ViewInteraction;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.Espresso.pressBack;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.replaceText;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static java.lang.Thread.sleep;
import static org.hamcrest.Matchers.allOf;

@LargeTest
@RunWith(AndroidJUnit4.class)
public class MainActivityTest {

    @Rule
    public ActivityTestRule<MainActivity> mActivityTestRule = new ActivityTestRule<>(MainActivity.class);

    @Test
    public void mainActivityTest() throws InterruptedException {
        ViewInteraction textView = onView(
                allOf(withId(android.R.id.text1), withText("Current BitCoin Rates"),
                        childAtPosition(
                                withId(R.id.menu),
                                0),
                        isDisplayed()));
        textView.perform(click());
        Thread.sleep(3000);
        pressBack();

        ViewInteraction textView2 = onView(
                allOf(withId(android.R.id.text1), withText("BitCoin Price Index Chart"),
                        childAtPosition(
                                withId(R.id.menu),
                                1),
                        isDisplayed()));
        textView2.perform(click());
        Thread.sleep(1000);
        ViewInteraction spinner = onView(
                allOf(withId(R.id.spinner), isDisplayed()));
        spinner.perform(click());

        ViewInteraction checkedTextView = onView(
                allOf(withId(android.R.id.text1), withText("5 days"), isDisplayed()));
        checkedTextView.perform(click());
        Thread.sleep(1000);
        pressBack();
        Thread.sleep(1000);
        ViewInteraction textView3 = onView(
                allOf(withId(android.R.id.text1), withText("Block information"),
                        childAtPosition(
                                withId(R.id.menu),
                                2),
                        isDisplayed()));
        textView3.perform(click());
        Thread.sleep(1000);
        ViewInteraction editText = onView(
                allOf(withId(R.id.edittextblock), isDisplayed()));
        editText.perform(replaceText("1"), closeSoftKeyboard());

        ViewInteraction button = onView(
                allOf(withId(R.id.blockbutton), withText("GO"), isDisplayed()));
        button.perform(click());
        Thread.sleep(1000);
        pressBack();

        Thread.sleep(1000);
        ViewInteraction textView4 = onView(
                allOf(withId(android.R.id.text1), withText("Address information"),
                        childAtPosition(
                                withId(R.id.menu),
                                3),
                        isDisplayed()));
        textView4.perform(click());

        ViewInteraction autoCompleteTextView = onView(
                allOf(withId(R.id.address_edit_text), isDisplayed()));
        autoCompleteTextView.perform(replaceText("1F1tAaz5x1HUXrCNLbtMDqcw6o5GNn4xqX"), closeSoftKeyboard());
        Thread.sleep(1000);
        ViewInteraction button4 = onView(
                allOf(withId(R.id.addressbutton), withText("GO"), isDisplayed()));
        button4.perform(click());
        Thread.sleep(1000);
    }

    private static Matcher<View> childAtPosition(
            final Matcher<View> parentMatcher, final int position) {

        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("Child at position " + position + " in parent ");
                parentMatcher.describeTo(description);
            }

            @Override
            public boolean matchesSafely(View view) {
                ViewParent parent = view.getParent();
                return parent instanceof ViewGroup && parentMatcher.matches(parent)
                        && view.equals(((ViewGroup) parent).getChildAt(position));
            }
        };
    }
}
